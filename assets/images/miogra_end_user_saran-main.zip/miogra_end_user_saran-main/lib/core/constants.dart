import 'package:flutter/material.dart';

const List<String> urls = [
  "https://i.pinimg.com/736x/83/1e/8a/831e8abf10dae58a8991330099e6ae0d.jpg",
  "https://i.pinimg.com/736x/23/e3/a5/23e3a59c694eb7e5d60b50194599b93d.jpg",
  "https://i.pinimg.com/736x/77/8e/81/778e81593b9cbe1f9b5d574a610e143f.jpg",
  "https://i.pinimg.com/736x/f4/a8/16/f4a8168b213ddd510dcfa48a2531a517.jpg",
  "https://sc04.alicdn.com/kf/H90886cb0b9f14919b7870fc6a8ce4cebk.jpg",
];

const List<String> urls1 = [
  "http://192.168.1.6:8000//media/api/shop_products/QMC77LVGSXM/other_images/nokkiya_Qgkzkw2.jpg",
  "http://192.168.1.6:8000//media/api/shop_products/QMC77LVGSXM/other_images/nokkiya_Qgkzkw2.jpg",
  "http://192.168.1.6:8000//media/api/shop_products/QMC77LVGSXM/other_images/nokkiya_Qgkzkw2.jpg",
  "http://192.168.1.6:8000//media/api/shop_products/QMC77LVGSXM/other_images/nokkiya_Qgkzkw2.jpg",
  "http://192.168.1.6:8000//media/api/shop_products/QMC77LVGSXM/other_images/nokkiya_Qgkzkw2.jpg",
  "http://192.168.1.6:8000//media/api/shop_products/QMC77LVGSXM/other_images/nokkiya_Qgkzkw2.jpg",

  
];

const lightBackgroundColor = Color(0xFFF2EBF1);

List<Map> addressAdd = [];
List<Map> updateAddressAdd = [];
