import 'package:flutter/material.dart';

const primaryColor = Color(0xFF870081);