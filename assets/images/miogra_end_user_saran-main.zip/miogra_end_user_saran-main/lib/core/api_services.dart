
class ApiServices {
  
  // static const String ipAddress = "10.0.2.2:8000";
  static const String ipAddress = "192.168.1.6:8000";
  // static const String ipAddress = "192.168.43.53:8000";



}



