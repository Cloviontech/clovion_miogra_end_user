import 'package:flutter/material.dart';

class ProductsDetailsUsedProduct extends StatelessWidget {
  const ProductsDetailsUsedProduct({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        
      ),
    );
  }
}