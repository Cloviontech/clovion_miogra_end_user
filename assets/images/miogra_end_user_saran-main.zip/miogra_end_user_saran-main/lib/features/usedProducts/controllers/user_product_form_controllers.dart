import 'package:flutter/material.dart';

final brandController = TextEditingController();
final modelNameController = TextEditingController();
final productDescriptionController = TextEditingController();
final contactController = TextEditingController();
final districtController = TextEditingController();
final yearAndMonthController = TextEditingController();

List<List<TextEditingController>> textEditingControllers = [];
