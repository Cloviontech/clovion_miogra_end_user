import 'package:flutter/material.dart';

final TextEditingController nameController= TextEditingController();
final TextEditingController mobileController= TextEditingController();
final TextEditingController alterNateNumController= TextEditingController();
final TextEditingController pinCodeController= TextEditingController();
final TextEditingController doorController= TextEditingController();
final TextEditingController areaController= TextEditingController();
final TextEditingController lanMarkController= TextEditingController();
final TextEditingController placeController= TextEditingController();
final TextEditingController districtController= TextEditingController();
final TextEditingController stateController= TextEditingController();