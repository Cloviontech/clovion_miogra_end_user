package com.example.miogra

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
